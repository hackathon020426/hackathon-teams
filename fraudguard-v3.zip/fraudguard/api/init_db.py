"""
FraudGuard — Initialisation SQLite
====================================
Tables :
  transactions  → toutes les transactions scorées
  alert_reviews → actions analyste (confirmer / rejeter)
"""

import os, json, sqlite3, joblib, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

BASE    = os.path.dirname(os.path.abspath(__file__))
ML_DIR  = os.path.join(BASE, "..", "ml")
DB_PATH = os.path.join(BASE, "..", "fraud.db")
CSV_PATH = os.path.join(BASE, "..", "data", "creditcard.csv")

SCHEMA = """
CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_idx INTEGER UNIQUE,   -- index dans le CSV original
    time_seconds    REAL,
    hour            INTEGER,
    amount          REAL,
    amount_scaled   REAL,
    v1  REAL, v2  REAL, v3  REAL, v4  REAL, v5  REAL,
    v6  REAL, v7  REAL, v8  REAL, v9  REAL, v10 REAL,
    v11 REAL, v12 REAL, v13 REAL, v14 REAL, v15 REAL,
    v16 REAL, v17 REAL, v18 REAL, v19 REAL, v20 REAL,
    v21 REAL, v22 REAL, v23 REAL, v24 REAL, v25 REAL,
    v26 REAL, v27 REAL, v28 REAL,
    class_label     INTEGER DEFAULT 0,
    fraud_score     REAL    DEFAULT 0.0,
    predicted_fraud INTEGER DEFAULT 0,
    risk_level      TEXT    DEFAULT 'low',
    review_status   TEXT    DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS alert_reviews (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_idx INTEGER NOT NULL,
    analyst_action  TEXT    NOT NULL,
    reviewed_at     TEXT    NOT NULL,
    notes           TEXT,
    FOREIGN KEY (transaction_idx) REFERENCES transactions(transaction_idx)
);

CREATE INDEX IF NOT EXISTS idx_class   ON transactions(class_label);
CREATE INDEX IF NOT EXISTS idx_score   ON transactions(fraud_score);
CREATE INDEX IF NOT EXISTS idx_risk    ON transactions(risk_level);
CREATE INDEX IF NOT EXISTS idx_review  ON transactions(review_status);
CREATE INDEX IF NOT EXISTS idx_hour    ON transactions(hour);
"""


def risk_level(score: float) -> str:
    if score < 0.3:  return "low"
    if score < 0.6:  return "medium"
    return "high"


def init_db(csv_path: str = CSV_PATH):
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"[db]  Ancienne base supprimée")

    # Charger modèle + scaler
    clf    = joblib.load(os.path.join(ML_DIR, "model.pkl"))
    scaler = joblib.load(os.path.join(ML_DIR, "scaler.pkl"))
    with open(os.path.join(ML_DIR, "model_meta.json")) as f:
        meta = json.load(f)

    FEATURE_COLS = meta["feature_cols"]
    THRESHOLD    = meta["optimal_threshold"]
    V_COLS       = meta["v_cols"]

    # Charger le CSV
    print(f"[db]  Lecture de {csv_path} …")
    df = pd.read_csv(csv_path)
    df["Hour"]         = (df["Time"] / 3600).astype(int) % 24
    df["Amount_scaled"] = scaler.transform(df[["Amount"]])

    # Scorer toutes les transactions
    print(f"[db]  Scoring de {len(df):,} transactions …")
    X = df[FEATURE_COLS].fillna(0)
    scores          = clf.predict_proba(X)[:, 1]
    df["fraud_score"]     = scores.round(4)
    df["predicted_fraud"] = (scores >= THRESHOLD).astype(int)
    df["risk_level"]      = [risk_level(s) for s in scores]

    print(f"[db]  Prédits fraud={df['predicted_fraud'].sum()} · "
          f"high_risk={(df['risk_level']=='high').sum()} · "
          f"seuil={THRESHOLD}")

    # Initialiser la DB
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    # Insérer par batch de 5000
    V_lower = [v.lower() for v in V_COLS]
    cols_sql = ",".join([
        "transaction_idx","time_seconds","hour","amount","amount_scaled"
    ] + V_lower + ["class_label","fraud_score","predicted_fraud","risk_level","review_status"])

    batch, BATCH_SIZE = [], 5000
    for idx, row in df.iterrows():
        v_vals = [round(float(row[v]), 6) for v in V_COLS]
        batch.append((
            int(idx),
            round(float(row["Time"]),     2),
            int(row["Hour"]),
            round(float(row["Amount"]),   4),
            round(float(row["Amount_scaled"]), 4),
            *v_vals,
            int(row["Class"]),
            round(float(row["fraud_score"]), 4),
            int(row["predicted_fraud"]),
            row["risk_level"],
            "pending",
        ))
        if len(batch) >= BATCH_SIZE:
            placeholders = ",".join(["?"] * (len(batch[0])))
            conn.executemany(
                f"INSERT OR IGNORE INTO transactions ({cols_sql}) VALUES ({placeholders})",
                batch
            )
            conn.commit()
            print(f"[db]  {idx+1:,} / {len(df):,} insérés…", end="\r")
            batch = []

    if batch:
        placeholders = ",".join(["?"] * (len(batch[0])))
        conn.executemany(
            f"INSERT OR IGNORE INTO transactions ({cols_sql}) VALUES ({placeholders})",
            batch
        )
        conn.commit()

    total = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
    frauds = conn.execute("SELECT COUNT(*) FROM transactions WHERE class_label=1").fetchone()[0]
    conn.close()

    print(f"\n[db]  {total:,} transactions · {frauds} fraudes → {DB_PATH}")
    print(f"[db]  Base prête.")


if __name__ == "__main__":
    init_db()
