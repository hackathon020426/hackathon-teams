"""
FraudGuard — API FastAPI v3
New endpoints:
  GET  /model/meta              → model metadata + training config
  POST /model/update-config     → update hyperparameters
  POST /model/retrain           → background retrain
  GET  /model/retrain/status    → retrain progress
  GET  /perf/test               → live perf benchmark on /predict
"""

import os, json, sqlite3, joblib, time, random, statistics
from datetime import datetime
from typing import Optional
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE    = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "..", "fraud.db")
ML_DIR  = os.path.join(BASE, "..", "ml")
GUI_DIR = os.path.join(BASE, "..", "gui")

# ── Model state ────────────────────────────────────────────────────────────────
_clf = _scaler = _meta = None
FEATURE_COLS = []; THRESHOLD = 0.5; V_COLS = []

def load_model():
    global _clf, _scaler, _meta, FEATURE_COLS, THRESHOLD, V_COLS
    try:
        _clf    = joblib.load(os.path.join(ML_DIR, "model.pkl"))
        _scaler = joblib.load(os.path.join(ML_DIR, "scaler.pkl"))
        with open(os.path.join(ML_DIR, "model_meta.json")) as f:
            _meta = json.load(f)
        FEATURE_COLS = _meta["feature_cols"]
        THRESHOLD    = _meta["optimal_threshold"]
        V_COLS       = _meta["v_cols"]
        print(f"[api] Model loaded · threshold={THRESHOLD}")
        return True
    except Exception as e:
        print(f"[api] WARN: {e}"); return False

load_model()

_retrain_state = {
    "status": "idle", "progress": "", "error": None,
    "started_at": None, "finished_at": None,
}

# ── DB ─────────────────────────────────────────────────────────────────────────
@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn; conn.commit()
    finally:
        conn.close()

def risk_level(score: float) -> str:
    return "high" if score >= 0.6 else "medium" if score >= 0.3 else "low"

def row_to_dict(r) -> dict:
    return dict(r)

# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(title="FraudGuard API", version="3.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Schemas ────────────────────────────────────────────────────────────────────
class PredictInput(BaseModel):
    time_seconds: float = Field(3600.0)
    amount:       float = Field(100.0)
    v1:float=0;  v2:float=0;  v3:float=0;  v4:float=0;  v5:float=0
    v6:float=0;  v7:float=0;  v8:float=0;  v9:float=0;  v10:float=0
    v11:float=0; v12:float=0; v13:float=0; v14:float=0; v15:float=0
    v16:float=0; v17:float=0; v18:float=0; v19:float=0; v20:float=0
    v21:float=0; v22:float=0; v23:float=0; v24:float=0; v25:float=0
    v26:float=0; v27:float=0; v28:float=0

class ReviewInput(BaseModel):
    analyst_action: str = Field(..., pattern="^(confirmed_fraud|false_positive)$")
    notes: Optional[str] = None

class ModelConfigInput(BaseModel):
    n_estimators:      Optional[int]   = Field(None, ge=50,  le=1000)
    max_depth:         Optional[int]   = Field(None, ge=3,   le=20)
    min_samples_leaf:  Optional[int]   = Field(None, ge=1,   le=10)
    optimal_threshold: Optional[float] = Field(None, ge=0.05, le=0.95)
    oversample_ratio:  Optional[float] = Field(None, ge=0.05, le=0.5)

# ── Helpers ────────────────────────────────────────────────────────────────────
def build_vector(t: PredictInput):
    import pandas as pd
    hour = int(t.time_seconds / 3600) % 24
    amt  = float(_scaler.transform([[t.amount]])[0][0])
    row  = {f"V{i}": getattr(t, f"v{i}") for i in range(1, 29)}
    row["Amount_scaled"] = amt; row["Hour"] = hour
    return pd.DataFrame([row])[FEATURE_COLS]

# ── Endpoints ──────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    with get_db() as db:
        total   = db.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        frauds  = db.execute("SELECT COUNT(*) FROM transactions WHERE class_label=1").fetchone()[0]
        pending = db.execute("SELECT COUNT(*) FROM transactions WHERE review_status='pending' AND class_label=1").fetchone()[0]
        new_rev = db.execute("SELECT COUNT(DISTINCT ar.transaction_idx) FROM alert_reviews ar JOIN transactions t ON ar.transaction_idx=t.transaction_idx WHERE t.class_label=0").fetchone()[0]
    return {"status":"ok","model_loaded":_clf is not None,"transactions":total,
            "frauds":frauds,"pending_alerts":pending,"new_analyst_reviews":new_rev,
            "threshold":THRESHOLD,"timestamp":datetime.utcnow().isoformat()}

@app.get("/transactions")
def list_transactions(
    page:int=Query(1,ge=1), size:int=Query(25,ge=1,le=200),
    fraud_only:bool=Query(False), risk:Optional[str]=Query(None),
    review:Optional[str]=Query(None), min_amount:Optional[float]=Query(None),
    max_amount:Optional[float]=Query(None), min_score:Optional[float]=Query(None),
    hour:Optional[int]=Query(None),
):
    f, p = [], []
    if fraud_only:             f.append("class_label=1")
    if risk:                   f.append("risk_level=?");    p.append(risk)
    if review:                 f.append("review_status=?"); p.append(review)
    if min_amount is not None: f.append("amount>=?");       p.append(min_amount)
    if max_amount is not None: f.append("amount<=?");       p.append(max_amount)
    if min_score  is not None: f.append("fraud_score>=?");  p.append(min_score)
    if hour       is not None: f.append("hour=?");          p.append(hour)
    w = ("WHERE " + " AND ".join(f)) if f else ""
    o = (page-1)*size
    with get_db() as db:
        total = db.execute(f"SELECT COUNT(*) FROM transactions {w}", p).fetchone()[0]
        rows  = db.execute(
            f"SELECT transaction_idx,time_seconds,hour,amount,class_label,fraud_score,"
            f"predicted_fraud,risk_level,review_status,v1,v4,v10,v14,v17 "
            f"FROM transactions {w} ORDER BY fraud_score DESC,transaction_idx ASC LIMIT ? OFFSET ?",
            p+[size,o]).fetchall()
    return {"total":total,"page":page,"size":size,"pages":max(1,(total+size-1)//size),"data":[row_to_dict(r) for r in rows]}

@app.get("/transactions/{tx_idx}")
def get_transaction(tx_idx: int):
    with get_db() as db:
        row = db.execute("SELECT * FROM transactions WHERE transaction_idx=?",(tx_idx,)).fetchone()
        if not row: raise HTTPException(404,f"Transaction {tx_idx} not found")
        reviews = db.execute("SELECT * FROM alert_reviews WHERE transaction_idx=? ORDER BY reviewed_at DESC",(tx_idx,)).fetchall()
    return {**row_to_dict(row),"reviews":[row_to_dict(r) for r in reviews]}

@app.post("/transactions/{tx_idx}/review")
def review_transaction(tx_idx: int, body: ReviewInput):
    with get_db() as db:
        row = db.execute("SELECT transaction_idx FROM transactions WHERE transaction_idx=?",(tx_idx,)).fetchone()
        if not row: raise HTTPException(404,f"Transaction {tx_idx} not found")
        now = datetime.utcnow().isoformat()
        db.execute("INSERT INTO alert_reviews (transaction_idx,analyst_action,reviewed_at,notes) VALUES (?,?,?,?)",(tx_idx,body.analyst_action,now,body.notes))
        db.execute("UPDATE transactions SET review_status=? WHERE transaction_idx=?",(body.analyst_action,tx_idx))
    return {"transaction_idx":tx_idx,"action":body.analyst_action,"reviewed_at":now}

@app.post("/predict")
def predict(t: PredictInput):
    if _clf is None: raise HTTPException(503,"Model not available — run ml/pipeline.py first")
    X = build_vector(t); score = float(_clf.predict_proba(X)[0,1])
    return {"fraud_score":round(score,4),"is_fraud":score>=THRESHOLD,"risk_level":risk_level(score),"threshold":THRESHOLD,"hour":int(t.time_seconds/3600)%24,"amount":t.amount}

@app.get("/stats")
def stats():
    with get_db() as db:
        t = db.execute("""SELECT COUNT(*) total,SUM(class_label) total_fraud,
            ROUND(AVG(fraud_score),4) avg_score,
            SUM(CASE WHEN risk_level='high'   THEN 1 ELSE 0 END) high_risk,
            SUM(CASE WHEN risk_level='medium' THEN 1 ELSE 0 END) medium_risk,
            SUM(CASE WHEN risk_level='low'    THEN 1 ELSE 0 END) low_risk,
            SUM(CASE WHEN review_status='pending' AND class_label=1 THEN 1 ELSE 0 END) pending_alerts,
            SUM(CASE WHEN review_status='confirmed_fraud' THEN 1 ELSE 0 END) confirmed,
            SUM(CASE WHEN review_status='false_positive'  THEN 1 ELSE 0 END) false_pos,
            ROUND(AVG(amount),2) avg_amount,ROUND(MAX(amount),2) max_amount
            FROM transactions""").fetchone()
        by_hour   = db.execute("SELECT hour,COUNT(*) total,SUM(class_label) frauds FROM transactions GROUP BY hour ORDER BY hour").fetchall()
        by_risk   = db.execute("SELECT risk_level,COUNT(*) cnt FROM transactions GROUP BY risk_level").fetchall()
        by_review = db.execute("SELECT review_status,COUNT(*) cnt FROM transactions WHERE class_label=1 GROUP BY review_status").fetchall()
        top_scores= db.execute("SELECT transaction_idx,amount,fraud_score,risk_level,review_status FROM transactions WHERE class_label=1 ORDER BY fraud_score DESC LIMIT 10").fetchall()
        score_dist= db.execute("SELECT CAST(ROUND(fraud_score*10-.5) AS INT) bucket,COUNT(*) cnt FROM transactions GROUP BY bucket ORDER BY bucket").fetchall()
        new_rev   = db.execute("SELECT COUNT(DISTINCT ar.transaction_idx) FROM alert_reviews ar JOIN transactions t ON ar.transaction_idx=t.transaction_idx WHERE t.class_label=0").fetchone()[0]
    return {
        "total_transactions":t["total"],"total_frauds":t["total_fraud"],
        "fraud_rate":round(t["total_fraud"]/max(t["total"],1),4),
        "avg_fraud_score":t["avg_score"],"high_risk":t["high_risk"],
        "medium_risk":t["medium_risk"],"low_risk":t["low_risk"],
        "pending_alerts":t["pending_alerts"],"confirmed_frauds":t["confirmed"],
        "false_positives":t["false_pos"],"avg_amount":t["avg_amount"],"max_amount":t["max_amount"],
        "new_analyst_reviews":new_rev,
        "by_hour":[row_to_dict(r) for r in by_hour],"by_risk":[row_to_dict(r) for r in by_risk],
        "by_review":[row_to_dict(r) for r in by_review],"top_fraud_scores":[row_to_dict(r) for r in top_scores],
        "score_distribution":[row_to_dict(r) for r in score_dist],
        "model_metrics":_meta.get("metrics",{}) if _meta else {},"optimal_threshold":THRESHOLD,
    }

# ── Model metadata & config ────────────────────────────────────────────────────
@app.get("/model/meta")
def get_model_meta():
    if not _meta: raise HTTPException(503,"Model not loaded")
    cfg = _meta.get("training_config",{"n_estimators":200,"max_depth":12,"min_samples_leaf":2,"oversample_ratio":0.1,"class_weight":"balanced"})
    return {"feature_cols":FEATURE_COLS,"optimal_threshold":THRESHOLD,"training_config":cfg,
            "dataset":_meta.get("dataset",{}),"metrics":_meta.get("metrics",{}),
            "trained_at":_meta.get("trained_at","N/A (initial model)"),
            "training_samples":_meta.get("training_samples","N/A"),
            "analyst_reviews_used":_meta.get("analyst_reviews_used",0),
            "retrain_state":_retrain_state}

@app.post("/model/update-config")
def update_config(body: ModelConfigInput):
    if not _meta: raise HTTPException(503,"Model not loaded")
    meta_path = os.path.join(ML_DIR,"model_meta.json")
    cfg = _meta.get("training_config",{"n_estimators":200,"max_depth":12,"min_samples_leaf":2,"oversample_ratio":0.1,"class_weight":"balanced"})
    updated = {}
    if body.n_estimators      is not None: cfg["n_estimators"]      = body.n_estimators;     updated["n_estimators"]      = body.n_estimators
    if body.max_depth         is not None: cfg["max_depth"]         = body.max_depth;        updated["max_depth"]         = body.max_depth
    if body.min_samples_leaf  is not None: cfg["min_samples_leaf"]  = body.min_samples_leaf; updated["min_samples_leaf"]  = body.min_samples_leaf
    if body.oversample_ratio  is not None: cfg["oversample_ratio"]  = body.oversample_ratio; updated["oversample_ratio"]  = body.oversample_ratio
    if body.optimal_threshold is not None:
        _meta["optimal_threshold"] = body.optimal_threshold
        updated["optimal_threshold"] = body.optimal_threshold
        global THRESHOLD; THRESHOLD = body.optimal_threshold
    _meta["training_config"] = cfg
    with open(meta_path,"w") as f: json.dump(_meta,f,indent=2)
    return {"updated":updated,"current_config":cfg,"threshold":THRESHOLD}

# ── Retrain ────────────────────────────────────────────────────────────────────
def _do_retrain(include_reviews: bool, config: dict):
    global _clf, _scaler, _meta, FEATURE_COLS, THRESHOLD, V_COLS, _retrain_state
    import warnings; warnings.filterwarnings("ignore")
    import numpy as np, pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import (roc_auc_score, average_precision_score,
                                  confusion_matrix, classification_report, precision_recall_curve)
    from sklearn.utils import resample as sk_res

    try:
        _retrain_state.update({"status":"running","error":None,"started_at":datetime.utcnow().isoformat(),"finished_at":None})
        CSV_PATH = os.path.join(ML_DIR,"..","data","creditcard.csv")

        _retrain_state["progress"] = "Loading creditcard.csv..."
        if not os.path.exists(CSV_PATH): raise FileNotFoundError(f"creditcard.csv not found at {CSV_PATH}")
        df = pd.read_csv(CSV_PATH)
        df["Hour"] = (df["Time"]/3600).astype(int)%24
        sc = StandardScaler()
        df["Amount_scaled"] = sc.fit_transform(df[["Amount"]])
        VC = [f"V{i}" for i in range(1,29)]; FEAT = VC+["Amount_scaled","Hour"]
        X = df[FEAT].copy(); y = df["Class"].copy()

        analyst_count = 0
        if include_reviews:
            _retrain_state["progress"] = "Loading analyst reviews..."
            with get_db() as db:
                revs = db.execute("""SELECT ar.analyst_action,
                    t.v1,t.v2,t.v3,t.v4,t.v5,t.v6,t.v7,t.v8,t.v9,t.v10,
                    t.v11,t.v12,t.v13,t.v14,t.v15,t.v16,t.v17,t.v18,t.v19,t.v20,
                    t.v21,t.v22,t.v23,t.v24,t.v25,t.v26,t.v27,t.v28,t.amount,t.hour
                    FROM alert_reviews ar JOIN transactions t ON ar.transaction_idx=t.transaction_idx
                    WHERE t.class_label=0 ORDER BY ar.reviewed_at DESC""").fetchall()
            if revs:
                rx,ry=[],[]
                for r in revs:
                    rd=dict(r); row={f"V{i}":rd[f"v{i}"] for i in range(1,29)}
                    row["Amount_scaled"]=float(sc.transform([[rd["amount"]]])[0][0]); row["Hour"]=rd["hour"]
                    rx.append(row); ry.append(1 if rd["analyst_action"]=="confirmed_fraud" else 0)
                X=pd.concat([X,pd.DataFrame(rx)[FEAT]],ignore_index=True)
                y=pd.concat([y,pd.Series(ry)],ignore_index=True)
                analyst_count=len(revs)
                _retrain_state["progress"]=f"Merged {analyst_count} analyst reviews"

        _retrain_state["progress"]="Splitting train/test (80/20 stratified)..."
        X_tr,X_te,y_tr,y_te=train_test_split(X,y,test_size=0.2,stratify=y,random_state=42)

        _retrain_state["progress"]="Oversampling minority class..."
        ratio=config.get("oversample_ratio",0.1)
        Xc=X_tr.copy(); Xc["__y__"]=y_tr.values
        maj=Xc[Xc["__y__"]==0]; mi=Xc[Xc["__y__"]==1]
        n_up=max(len(mi),int(len(maj)*ratio))
        mi_up=sk_res(mi,replace=True,n_samples=n_up,random_state=42)
        bal=pd.concat([maj,mi_up]).sample(frac=1,random_state=42)

        _retrain_state["progress"]=f"Training Random Forest ({config.get('n_estimators',200)} trees, depth={config.get('max_depth',12)})..."
        clf=RandomForestClassifier(n_estimators=config.get("n_estimators",200),
            max_depth=config.get("max_depth",12),min_samples_leaf=config.get("min_samples_leaf",2),
            class_weight="balanced",random_state=42,n_jobs=-1)
        clf.fit(bal[FEAT],bal["__y__"])

        _retrain_state["progress"]="Evaluating model..."
        y_pred=clf.predict(X_te); y_proba=clf.predict_proba(X_te)[:,1]
        classes=y_te.unique()
        auc=float(roc_auc_score(y_te,y_proba)) if len(classes)>1 else 0.0
        ap=float(average_precision_score(y_te,y_proba)) if len(classes)>1 else 0.0
        cm=confusion_matrix(y_te,y_pred).tolist()
        rep=classification_report(y_te,y_pred,target_names=["Legitimate","Fraud"],output_dict=True) if len(classes)>1 else {}
        prec,rec,thr=precision_recall_curve(y_te,y_proba)
        f1=2*prec*rec/(prec+rec+1e-9); bi=f1.argmax()
        opt=float(thr[bi]) if bi<len(thr) else 0.5

        _retrain_state["progress"]="Saving model.pkl + scaler.pkl..."
        joblib.dump(clf,os.path.join(ML_DIR,"model.pkl"))
        joblib.dump(sc, os.path.join(ML_DIR,"scaler.pkl"))
        meta_new={"feature_cols":FEAT,"v_cols":VC,"optimal_threshold":round(opt,3),
            "training_config":config,"trained_at":datetime.utcnow().isoformat(),
            "include_reviews":include_reviews,"training_samples":len(bal),
            "analyst_reviews_used":analyst_count,
            "metrics":{"auc_roc":round(auc,4),"avg_precision":round(ap,4),
                "optimal_threshold":round(opt,3),"confusion_matrix":cm,
                "classification_report":rep,
                "feature_importances":{c:round(float(v),4) for c,v in zip(FEAT,clf.feature_importances_)}},
            "dataset":{"name":"Kaggle ULB + Analyst Reviews" if include_reviews else "Kaggle ULB"}}
        with open(os.path.join(ML_DIR,"model_meta.json"),"w") as f: json.dump(meta_new,f,indent=2)

        _retrain_state["progress"]="Rescoring all DB transactions..."
        with get_db() as db:
            all_tx=db.execute("SELECT transaction_idx,"+",".join(f"v{i}" for i in range(1,29))+",amount,hour FROM transactions").fetchall()
            batch=[]
            for row in all_tx:
                rd=dict(row); fr={f"V{i}":rd[f"v{i}"] for i in range(1,29)}
                fr["Amount_scaled"]=float(sc.transform([[rd["amount"]]])[0][0]); fr["Hour"]=rd["hour"]
                Xr=pd.DataFrame([fr])[FEAT]; score=float(clf.predict_proba(Xr)[0,1])
                rl="high" if score>=opt else "medium" if score>=0.3 else "low"
                batch.append((round(score,4),int(score>=opt),rl,rd["transaction_idx"]))
            db.executemany("UPDATE transactions SET fraud_score=?,predicted_fraud=?,risk_level=? WHERE transaction_idx=?",batch)

        load_model()
        _retrain_state.update({"status":"done","progress":"Retrain complete ✓","finished_at":datetime.utcnow().isoformat()})
    except Exception as e:
        _retrain_state.update({"status":"error","error":str(e),"progress":"Failed","finished_at":datetime.utcnow().isoformat()})

@app.post("/model/retrain")
def retrain(background_tasks: BackgroundTasks, include_reviews:bool=Query(False)):
    if _retrain_state["status"]=="running": raise HTTPException(409,"Retrain already in progress")
    try:
        with open(os.path.join(ML_DIR,"model_meta.json")) as f: m=json.load(f)
    except: m={}
    cfg=m.get("training_config",{"n_estimators":200,"max_depth":12,"min_samples_leaf":2,"oversample_ratio":0.1})
    _retrain_state.update({"status":"starting","progress":"Queued...","error":None})
    background_tasks.add_task(_do_retrain,include_reviews,cfg)
    return {"message":"Retrain started","include_reviews":include_reviews,"config":cfg}

@app.get("/model/retrain/status")
def retrain_status(): return _retrain_state

# ── Perf test ──────────────────────────────────────────────────────────────────
@app.get("/perf/test")
def perf_test(n:int=Query(50,ge=10,le=500), threads:int=Query(10,ge=1,le=50)):
    import concurrent.futures, pandas as pd, warnings; warnings.filterwarnings("ignore")
    if _clf is None: raise HTTPException(503,"Model not available")

    def make_payload(fraud=False):
        v14=random.uniform(-6,-3) if fraud else random.gauss(0,1)
        v1 =random.uniform(-3,-1) if fraud else random.gauss(0,1)
        p={"time_seconds":random.uniform(0,172800),"amount":random.uniform(1,500)}
        for i in range(1,29): p[f"v{i}"]=random.gauss(0,1)
        p["v1"]=v1; p["v14"]=v14; return p

    def run_one(payload):
        t0=time.perf_counter()
        try:
            hour=int(payload["time_seconds"]/3600)%24
            amt_sc=float(_scaler.transform([[payload["amount"]]])[0][0])
            row={f"V{i}":payload[f"v{i}"] for i in range(1,29)}
            row["Amount_scaled"]=amt_sc; row["Hour"]=hour
            X=pd.DataFrame([row])[FEATURE_COLS]
            score=float(_clf.predict_proba(X)[0,1])
            ms=(time.perf_counter()-t0)*1000
            return {"ok":True,"latency_ms":round(ms,2),"score":score,"risk":risk_level(score),"is_fraud":score>=THRESHOLD}
        except Exception as e:
            return {"ok":False,"latency_ms":round((time.perf_counter()-t0)*1000,2),"error":str(e)}

    payloads=[make_payload(fraud=(i%10==0)) for i in range(n)]
    t_start=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        results=list(ex.map(run_one,payloads))
    elapsed=time.perf_counter()-t_start

    ok=[r for r in results if r["ok"]]; fail=[r for r in results if not r["ok"]]
    lats=sorted(r["latency_ms"] for r in ok)
    def pct(lst,p): return lst[max(0,int(len(lst)*p/100)-1)] if lst else None
    risk_dist={}
    for r in ok: risk_dist[r["risk"]]=risk_dist.get(r["risk"],0)+1

    return {
        "config":{"n_requests":n,"n_threads":threads,"mix":"90% legitimate / 10% fraud pattern"},
        "results":{"total":n,"success":len(ok),"errors":len(fail),
            "error_rate":round(len(fail)/n,4),"elapsed_s":round(elapsed,3),
            "throughput_rps":round(n/elapsed,1)},
        "latency_ms":{"min":round(lats[0],1) if lats else None,
            "mean":round(statistics.mean(lats),1) if lats else None,
            "median":round(statistics.median(lats),1) if lats else None,
            "p75":round(pct(lats,75),1) if lats else None,
            "p95":round(pct(lats,95),1) if lats else None,
            "p99":round(pct(lats,99),1) if lats else None,
            "max":round(lats[-1],1) if lats else None},
        "score_distribution":{"flagged_fraud":sum(1 for r in ok if r["is_fraud"]),"by_risk":risk_dist},
        "interpretation":{"throughput":"Predictions per second the model sustains under load",
            "p95":"95% of requests complete within this latency — the practical user experience ceiling",
            "p99":"99th percentile — worst-case latency excluding extreme outliers",
            "gil_note":"Python GIL limits parallelism for scikit-learn. Use uvicorn --workers 4 to scale throughput linearly.",
            "null_means":"null = metric could not be computed (no successful requests)"},
    }

# ── Serve GUI ──────────────────────────────────────────────────────────────────
if os.path.isdir(GUI_DIR):
    app.mount("/static", StaticFiles(directory=GUI_DIR), name="static")
    @app.get("/")
    def serve_gui(): return FileResponse(os.path.join(GUI_DIR,"index.html"))
